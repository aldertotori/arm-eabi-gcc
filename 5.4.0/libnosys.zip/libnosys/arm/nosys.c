
#include <stdlib.h>
#include <stdio.h>
#include <_ansi.h>
#include <_syslist.h>
#include <sys/times.h>
#include <errno.h>
#undef errno

int errno;

char *__env[1] = { 0 }; 
char **environ = __env; 

int
_open (char *file,
        int   flags,
        int   mode)
{
	errno = ENOSYS;
	return -1;
}

int
_isatty(int file)
{
	errno = ENOSYS;
	return 0;
}

int
_close (int fildes)
{
	errno = ENOSYS;
	return -1;
}

void
_exit(int rc)
{
	while(1);
}

int
_fstat(int fildes,struct stat *st)
{
	errno = ENOSYS;
	return -1;
}

int
_kill(int pid,int sig)
{
	errno = ENOSYS;
	return -1;
}

int
_lseek(int   file,
        int   ptr,
        int   dir)
{
	errno = ENOSYS;
	return -1;
}

int
_stat (const char  *file ,struct stat *st)
{
	errno = ENOSYS;
	return -1;
}

int
_write(int   file ,
        char *ptr ,
        int   len)
{
	errno = ENOSYS;
	return -1;
}

int
_chown(const char *path,
        uid_t owner,
        gid_t group)
{
	errno = ENOSYS;
	return -1;
}

void *
_sbrk (int incr)
{ 
	extern char   end; /* Set by linker.  */
	static char * heap_end; 
	char *        prev_heap_end; 
	
	if (heap_end == 0)
		heap_end = & end; 
	
	prev_heap_end = heap_end; 
	heap_end += incr; 
	
	return (void *) prev_heap_end; 
} 

int
_execve(char  *name,
        char **argv,
        char **env)
{
	errno = ENOSYS;
	return -1;
}

int
_read (int   file,
        char *ptr,
        int   len)
{
	errno = ENOSYS;
	return -1;
}

int
_getpid (void)
{
	errno = ENOSYS;
	return -1;
}

int
_fork(void)
{
	errno = ENOSYS;
	return -1;
}

clock_t
_times(struct tms *buf)
{
	errno = ENOSYS;
	return -1;
}

int
_wait(int  *status)
{
	errno = ENOSYS;
	return -1;
}

int
_gettimeofday (struct timeval  *ptimeval,void *ptimezone)
{
	errno = ENOSYS;
	return -1;
}

int
_link(char *existing,char *newss)
{
	errno = ENOSYS;
	return -1;
}

int
_readlink (const char *path,char *buf,size_t bufsize)
{
	errno = ENOSYS;
	return -1;
}

int
_symlink (const char *path1,
        const char *path2)
{
	errno = ENOSYS;
	return -1;
}

int
_unlink (char *name)
{
	errno = ENOSYS;
	return -1;
}
